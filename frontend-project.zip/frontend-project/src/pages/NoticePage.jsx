import Header from '../components/Header';
import AppFooter from '../components/AppFooter';

function notice(){


    return (
        <div>
             <Header />



             <AppFooter/>
        </div>
    )
}

export default notice