function Inquery() {
    return (
        <div>
            <h2>1:1 문의</h2>
            <p>여기에 1:1 문의 폼이 표시됩니다.</p>
        </div>
    );
}