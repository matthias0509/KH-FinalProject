function FAQ() {
    return (
        <div>
            <h2>자주 묻는 질문</h2>
            <p>여기에 자주 묻는 질문과 답변이 표시됩니다.</p>
        </div>
    );
}